# Walldraw
墙画机

拿着手机不知所措的同学，请按上面的 View code 就可以看到程序和说明书了，部分手机不能在线阅读pdf，可以下载后再看。
下载是按绿色的 Clone or Download 按钮下载zip的打包文件。

如果还是不会，请Google一下看看GitHub咋用，或者放弃后到 https://create.arduino.cc/editor/wjd76/f6e291a3-1061-4218-b583-fa0fd5550cfb/preview 用web版编译器编译

也可以到本店的西瓜视频观看教程 https://www.ixigua.com/home/2123847662571084/

推荐直接使用Arduino.cc官网的web版编译器 部分内容可能翻墙后更方便，推荐一个翻墙工具， https://github.com/bannedbook/fanqiang/wiki

请勿使用旺旺咨询任何关于程序调试、翻墙工具使用的任何问题。我们只能保证程序可以运行，关于程序问题，请自行解决。如果没有调试运行Arduino程序的基础知识，请谨慎购买。
